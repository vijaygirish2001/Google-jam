# -*- coding: utf-8 -*-
{
'host'                : 'code.google.com',
'user'                : 'your-name-here@gmail.com',
'data_directory'      : './source',
'input_name_format'   : '{problem}-{input}-{id}.in',
'output_name_format'  : '{problem}-{input}-{id}.out',
'source_names_format' : ['{problem}-{input}-{id}.cpp'],
}
