function mySoundOn()
%Plays the sound of a gong being played
load gong.mat
sound(y,Fs*2);

%Troy Jamison
%Nick R.
%Project 1 ECE 102