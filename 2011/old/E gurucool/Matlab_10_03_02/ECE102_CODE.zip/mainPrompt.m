function [choice]=mainPrompt()


prompt='Please choose an operation:'
userInput=menu(prompt,'Light Sequence','Binary Counter');
choice=userInput;