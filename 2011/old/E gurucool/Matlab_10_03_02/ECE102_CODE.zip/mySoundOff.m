function mySoundOff()
%Plays the sound of a gong being played
load chirp.mat
sound(y,Fs);

%Troy Jamison
%Nick R.
%Project 1 ECE 102