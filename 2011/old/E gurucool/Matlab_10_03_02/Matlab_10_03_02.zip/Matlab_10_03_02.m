clear all;              %Remopves all the variables from workspace
close all;
clc;

% Initiate labjack
% Loads LabJack UD Function Library
ljud_LoadDriver; 

% Loads LabJack UD constant files
ljud_Constants; 
[Error ljHandle] = ljud_OpenLabJack(LJ_dtU3,LJ_ctUSB,'1',1);
Error_Message(Error) 

%reset I/O channels
Error = ljud_ePut(ljHandle, LJ_ioPIN_CONFIGURATION_RESET,0,0,0);


% Set analog input FIO7 for momentory switch and FIO3 for photocell
Error = ljud_ePut(ljHandle, LJ_ioPUT_ANALOG_ENABLE_BIT,7,1,0);

%Read the voltage at FIO7
[Error volt]= ljud_eGet(ljHandle, LJ_ioGET_AIN,7,0,0);
Error_Message(Error)

%Enable FIO3 to be an analog input for photocell
Error = ljud_ePut(ljHandle, LJ_ioPUT_ANALOG_ENABLE_BIT,3,1,0);

%Read the voltage at FIO3
[Error volt1]= ljud_eGet(ljHandle, LJ_ioGET_AIN,3,0,0);
Error_Message(Error)


true = 1;

%start counting the switch event
global cnt;
cnt=0;


%x is a variable for forword sequence
x=0;

%y is a variable for reverse sequence
y=2;


choice=menu('Please select one of the option:','Light Sequence','Binary Counter');


 
    if volt1>1
        if choice==1
        prompt={'How long should light display in sec:'};
        dlg_title='Light Timer';
        num_lines=1;
        def={'1'};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        minlight=answer{1};

        lightTimer=str2double(minlight);


   

        %Run a binary count using the LED's
        else(choice==2)
            while volt1>1                       %photocell is exposed
             [Error volt1]= ljud_eGet(ljHandle, LJ_ioGET_AIN,3,0,0);

              for(light=0:7) 

              counter_binary=dec2bin(light,3);


    %   Binary 0

                                  number=dec2bin(0,3);
                if (strcmp(counter_binary,number))

                    %No light will ever display   
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);
                                    disp(counter_binary)
                                     pause(1)
                end

    %    Binary 1
                           number=dec2bin(1,3);
                 if strcmp(counter_binary,number)

                    %Turn lights on
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);

                                    disp(counter_binary)
                                       pause(1)

                     %Turn lights off                  
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 end
    %                            Binary 2
                number=dec2bin(2,3);
                if strcmp(counter_binary,number)

                    %Turn lights on
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);

                                    disp(counter_binary)       
                                        pause(1)

                     %Turn lights off                   
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                end
    %                                 Binary 3
                    number=dec2bin(3,3);
                if strcmp(counter_binary,number)

                    %Turn lights on
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);

                                   disp(counter_binary)
                                      pause(1)

                      %Turn lights off                
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                end 

    %                                    Binary 4
                number=dec2bin(4,3);
                if strcmp(counter_binary,number)

                    %Turn lights on
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 1, 0);

                            disp(counter_binary) 
                                pause(1)

                     %Turn lights off           
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);
                end               
    
    %                                   Binary 5
                number=dec2bin(5,3);
                if strcmp(counter_binary,number)

                    %Turn lights on
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 1, 0);

                                disp(counter_binary)
                                    pause(1)

                     %Turn lights off                
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);
                end
    %                                  Binary 6
                 number=dec2bin(6,3);
                if strcmp(counter_binary,number)

                    %Turn lights on                
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 1, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 1, 0);

                            disp(counter_binary)
                               pause(1)

                    %Turn lights off
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                 Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);
                end
    %                                 Binary 7
                number=dec2bin(7,3);
                if strcmp(counter_binary,number)

                    %Turn on lights
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 1, 0);
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 1, 0);
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 1, 0);

                            disp(counter_binary) %Print binary output
                            pause(1) %Wait 1 sec then proceed

                    %Turn lights off
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 4, 0, 0);
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 5, 0, 0);
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, 6, 0, 0);

                end
             end
    end

        end
    end


%This loop will be continous until the
%photocell is exposed to room light

%*************************************************************************

while(volt1 > 1)%go inside the "while" statement if the measured voltage is more than 2V (i.e. The switch is ON)
    [Error volt1]= ljud_eGet(ljHandle, LJ_ioGET_AIN,3,0,0);

%count was preset above as 0 so lights will always start in forward sequence   
    if(mod(count,2) == 0)
%   Forward Sequence Code
    % Lights will go from left to right

        
            %Check to see if the button is press if it has switch sequences          
               [Error volt]= ljud_eGet(ljHandle, LJ_ioGET_AIN,7,1,0);%Measure the voltage at FIO7
    
                    if(volt > 1)%go inside the "if" statement if the measured voltage is more than 2V (i.e. The switch is ON)
                        pause(1)%Wait 1sec to avoid bouncing

                        disp('switch is on')%Tell the user that the switch was pressed.
                         count = count + 1%increment by 1 every time switch is pressed.
                            pause(1)
                          fprintf('count =  %d times\n', count);%Show how many times the switch is pressed so far!


                        end
            
            %Turn the light on
            Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, x, 1, 0);
           
            pause(lightTimer)
                
            %Turn the light off
            Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, x, 0, 0);
           load chirp.mat
            sound(y,Fs);
      
           
            %Check to see if the button is press if it has switch sequences          
               [Error volt]= ljud_eGet(ljHandle, LJ_ioGET_AIN,7,1,0);%Measure the voltage at FIO7
    
                    if(volt > 1)%go inside the "if" statement if the measured voltage is more than 2V (i.e. The switch is ON)
                        pause(1)%Wait 1sec to avoid bouncing

                        disp('switch is on')%Tell the user that the switch was pressed.
                         count = count + 1%increment by 1 every time switch is pressed.
                            pause(1)
                          fprintf('count =  %d times\n', count);%Show how many times the switch is pressed so far!


                        end
            %This will increment X so we switch FIO# to control next light
            x=x+1;
            

    % reset after every loop%

            if(x>2) 
                        
                x=0;
            end
    disp(count)
         
     
     elseif(mod(count,2)~=0) % Reverse the Lights directions
         

%                         Reverse Sequence Code

                       

 %Check to see if the button is press if it has switch sequences          
               [Error volt]= ljud_eGet(ljHandle, LJ_ioGET_AIN,7,1,0);%Measure the voltage at FIO7
    
                    if(volt > 1)%go inside the "if" statement if the measured voltage is more than 2V (i.e. The switch is ON)
                        pause(1)%Wait 1sec to avoid bouncing

                        disp('switch is on')%Tell the user that the switch was pressed.
                         count = count + 1%increment by 1 every time switch is pressed.
                            pause(1)
                          fprintf('count =  %d times\n', count);%Show how many times the switch is pressed so far!


                        end
            
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, y, 1, 0);
                
                pause(lightTimer)
                
     
            %Check to see if the button is press if it has switch sequences          
            count = ButtonPressChecker();
            
                Error = ljud_ePut (ljHandle, LJ_ioPUT_DIGITAL_BIT, y, 0, 0);
                
                               
                count = ButtonPressChecker();
        load chirp.mat
            sound(y,Fs);
                %Reverse count 
                
            %Check to see if the button is press if it has switch sequences          
               [Error volt]= ljud_eGet(ljHandle, LJ_ioGET_AIN,7,1,0);%Measure the voltage at FIO7
    
                    if(volt > 1)%go inside the "if" statement if the measured voltage is more than 2V (i.e. The switch is ON)
                        pause(1)%Wait 1sec to avoid bouncing

                        disp('switch is on')%Tell the user that the switch was pressed.
                         count = count + 1%increment by 1 every time switch is pressed.
                            pause(1)
                          fprintf('count =  %d times\n', count);%Show how many times the switch is pressed so far!


                        end
                y=y-1;
 
    %reset after every loop%

                if(y<0)             %
                                    %
                    y=2;            %
                                    %
                end                 %
    
                        
            end

                
    
end

